const mongoose = require('mongoose');
const { Schema } = mongoose;
const oid = (ref, required = true) => ({ type: Schema.Types.ObjectId, ref, required });

const userSchema = new Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true, lowercase: true },
  passwordHash: { type: String, required: true },
  role: { type: String, enum: ['parent', 'therapist'], required: true }
});

const childSchema = new Schema({
  parentId: oid('User'),
  name: { type: String, required: true },
  dob: { type: Date, required: true },
  interests: [String],
  notes: String,
  primaryTriggers: [String],
  calmingStrategies: [String],
  grants: [{ type: Schema.Types.ObjectId, ref: 'User' }]
});

const episodeSchema = new Schema({
  childId: oid('Child'),
  ts: { type: Date, default: Date.now },
  intensity: { type: Number, min: 1, max: 5, required: true },
  location: String,
  activity: String,
  trigger: String,
  sensoryEnvironment: String,
  sleepHours: Number,
  hungerLevel: String,
  behaviors: [String],
  durationMinutes: Number,
  response: String,
  recoveryMinutes: Number,
  calmingInterventions: [String],
  postEpisodeBehavior: String,
  notes: String
});

const noteSchema = new Schema({
  childId: oid('Child'),
  author: { type: String, required: true },
  authorRole: String,
  ts: { type: Date, default: Date.now },
  text: { type: String, required: true }
});

const contactSchema = new Schema({
  childId: oid('Child'),
  name: { type: String, required: true },
  role: String,
  phone: String,
  email: String
});

const goalSchema = new Schema({
  childId: oid('Child'),
  area: String,
  title: String,
  targetScore: Number,
  currentScore: Number
});

const progressSchema = new Schema({
  childId: oid('Child'),
  goalId: oid('Goal', false),
  ts: { type: Date, default: Date.now },
  area: String,
  score: Number,
  obs: String
});

const milestoneSchema = new Schema({
  childId: oid('Child'),
  title: String,
  ts: { type: Date, default: Date.now }
});

const routineSchema = new Schema({
  childId: oid('Child'),
  title: { type: String, required: true },
  category: String,
  scheduleTime: String,
  completed: { type: Boolean, default: false },
  steps: [String],
  days: { type: [Number], default: [0, 1, 2, 3, 4, 5, 6] },
  active: { type: Boolean, default: true },
  supports: String
});

const routineLogSchema = new Schema({
  routineId: oid('Routine'),
  date: String,
  status: { type: String, enum: ['completed', 'pending', 'skipped'], default: 'pending' }
});

const activitySchema = new Schema({
  title: { type: String, required: true },
  category: String,
  description: String,
  minAge: Number,
  maxAge: Number,
  tags: [String],
  minutes: Number,
  materials: [String],
  steps: [String]
});
const activityPlanSchema = new Schema({
  childId: oid('Child'),
  activityId: oid('Activity'),
  kind: { type: String, enum: ['favorite', 'planned'], required: true },
  date: String,
  done: { type: Boolean, default: false }
});
activityPlanSchema.index({ childId: 1, activityId: 1, kind: 1, date: 1 });

const activityFeedbackSchema = new Schema({
  activityId: oid('Activity'),
  childId: oid('Child'),
  rating: String,
  notes: String,
  ts: { type: Date, default: Date.now }
});

const learningProgressSchema = new Schema({
  parentId: oid('User'),
  moduleSlug: { type: String, required: true },
  lessons: [{ _id: false, subId: String, correct: Number, total: Number, completedAt: Date }],
  quizzes: [{ _id: false, chapterId: String, best: Number, last: Number, total: Number, attempts: { type: Number, default: 0 }, lastAt: Date }],
  activityDays: [String],
  lastActiveAt: Date
});
learningProgressSchema.index({ parentId: 1, moduleSlug: 1 }, { unique: true });

const teachingSubmissionSchema = new Schema({
  childId: oid('Child'),
  parentId: oid('User'),
  moduleSlug: { type: String, required: true },
  worksheetId: { type: String, required: true },
  ts: { type: Date, default: Date.now },
  day: String,
  score: { type: Number, required: true },
  max: { type: Number, required: true },
  percent: { type: Number, required: true },
  area: String,
  engagement: { type: Number, min: 1, max: 5 },
  minutes: { type: Number, min: 0, max: 180 },
  notes: { type: String, maxlength: 1000, default: '' },
  marks: [{ _id: false, itemId: String, level: { type: Number, min: 0, max: 2 } }],
  file: { data: Buffer, mime: String, name: String },
  progressId: { type: Schema.Types.ObjectId, ref: 'Progress' },
  milestoneId: { type: Schema.Types.ObjectId, ref: 'Milestone' }
});
teachingSubmissionSchema.index({ childId: 1, ts: -1 });

module.exports = {
  User: mongoose.model('User', userSchema),
  Child: mongoose.model('Child', childSchema),
  Episode: mongoose.model('Episode', episodeSchema),
  Note: mongoose.model('Note', noteSchema),
  Contact: mongoose.model('Contact', contactSchema),
  Goal: mongoose.model('Goal', goalSchema),
  Progress: mongoose.model('Progress', progressSchema),
  Milestone: mongoose.model('Milestone', milestoneSchema),
  Routine: mongoose.model('Routine', routineSchema),
  RoutineLog: mongoose.model('RoutineLog', routineLogSchema),
  Activity: mongoose.model('Activity', activitySchema),
  ActivityPlan: mongoose.model('ActivityPlan', activityPlanSchema),
  ActivityFeedback: mongoose.model('ActivityFeedback', activityFeedbackSchema),
  LearningProgress: mongoose.model('LearningProgress', learningProgressSchema),
  TeachingSubmission: mongoose.model('TeachingSubmission', teachingSubmissionSchema)
};